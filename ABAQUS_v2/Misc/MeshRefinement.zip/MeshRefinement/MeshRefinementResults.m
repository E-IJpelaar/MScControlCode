clear all;close all;clc;

n_nodes = [17.5;27;41;60;100;167];
x_coord  = [-4.8281 ; -1.8429; -8.8395 ; 0.3340  ; -0.2716; -0.0759];
y_coord  = [ 15.2920; 22.2886;  32.1358;  35.1187 ;   35.1734;     35.1270];
z_coord  = [ 3.3913;  -0.0858 ;  0.0640;   -0.2275 ;   -0.0689;   0.0156];

figure(1);
plot(n_nodes,y_coord,'LineWidth',2)
hold on;grid on;box on;
plot(n_nodes,y_coord,'o','MarkerSize',8,'MarkerFaceColor','r')
xlabel('Amount of Nodes x1000 [-]')
ylabel('Elongation in y-direction [mm]')
